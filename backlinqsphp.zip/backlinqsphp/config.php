<?php
/**
 * Description: Config file
 */
define("USER", "jtrimm_backlinq");
define("DATA", "jtrimm_backlinqs");
define("PASS", "X2Tsh0XOwRTRv");
define("ROOT", $_SERVER['DOCUMENT_ROOT']);
define("HOST", $_SERVER['HTTP_HOST']);
define("SERVER", $_SERVER['SERVER_NAME']);

$conString = "mysql:host=localhost;dbname=".DATA.";";

define("CONNETIONSTRING", $conString);