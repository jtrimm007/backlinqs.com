<?php

include 'config.php';


foreach ( glob("includes/*.php") as $file)
{
    include_once $file;
}


/**
 * Description: Checks titles before inserting post.
 * @param $userId
 * @param $postTitle
 * @param $content
 */
function CheckCurrentUserPostTitlesAndInsert($userId, $postTitle, $content)
{

    $storedPostTitles = GetAllPostTitles();

    $check = CheckPostTitles($postTitle);
    //var_dump($check);
    $dupCheck = CheckPostTitles($postTitle.' DUPLICATE');

    if($check == false)
    {
        InsertPostQuery($userId, $postTitle, $content);
    }
    elseif ($dupCheck == false && $check == true)
    {

        $duplicateTitle = $postTitle . ' DUPLICATE';
        InsertPostQuery($userId, $duplicateTitle, $content);

    }
    else{
        echo '<h3>Please choose a different title</h3>';
    }
}



function CheckCurrentUserLinkTitlesAndInsert($currentUser, $linkUrl, $linkDescription, $linkTitle)
{
    $currentUserLinkTitles = SelectAllCurrentUserLinks($currentUser);

    if(!in_array($linkTitle, $currentUserLinkTitles))
    {
        InsertLink($currentUser, $linkUrl, $linkDescription, $linkTitle);
    }
}

/**
 * @param $postId
 * @return array
 */
function GetCurrentPageContentWithPostId($postId)
{
    $postObjectArray = array();

    $query = new DatabaseQuery(USER, PASS, CONNETIONSTRING);

    $results = $query->SelectContentWithPostId($postId);

    $query->CloseConnection();

    if($results != null)
    {
        foreach ($results as $result)
        {

            array_push($postObjectArray, $result);
        }
    }

    return $postObjectArray;

}

/**
 * Description: Gets the current page title and content based upon the permalink
 * @param $permalink
 * @return array
 */
function GetCurrentPageContentWithPermalink($permalink)
{
    $postObjectArray = array();

    $query = new DatabaseQuery(USER, PASS, CONNETIONSTRING);

    $results = $query->SelectContentWithPermalink($permalink);
    //var_dump($results);

    $query->CloseConnection();

    if($results != null)
    {
        foreach ($results as $result)
        {

            array_push($postObjectArray, $result);
        }
    }
    //var_dump($postObjectArray);
    return $postObjectArray;

}

/**
 * Description: Gets the current linq Page based upon permalink
 * @param $permalink
 * @return array
 */
function GetCurrentLinkPageContentWithPermalink($permalink)
{

    $postObjectArray = array();

    $query = new DatabaseQuery(USER, PASS, CONNETIONSTRING);

    $results = $query->SelectContentWithPermalinkFromLinks($permalink);


    $query->CloseConnection();

    if($results != null)
    {

        foreach ($results as $result)
        {
            array_push($postObjectArray, $result);
        }
    }

    return $postObjectArray;

}

/**
 * @return mixed
 */
function GetPostInfoFromDatabase()
{

    $query = new DatabaseQuery(USER, PASS, CONNETIONSTRING);

    $results = $query->SelectAll('backlinqs_post');


    $query->CloseConnection();

    echo '<ul>';
    foreach ($results as $result)
    {
        echo '<li><a href="?id=' . $result['PostId'] . '">' . $result['Title'] . '</a></li>';

    }
    echo '</ul>';

    //return $results;

}

/**
 * Description: Inserts a post into the database
 * @param $currentUser
 * @param $title
 * @param $content
 */
function InsertPostQuery($currentUser, $title, $content)
{
    $query = new DatabaseQuery(USER, PASS, CONNETIONSTRING);


    $insert = $query->InsertPost($currentUser, $title, $content);


    //var_dump($insert);
    $query->CloseConnection();

}

function InsertLink($currentUser, $linkUrl, $linkDescription, $linkTitle)
{
    $query = new DatabaseQuery(USER, PASS, CONNETIONSTRING);


    $insert = $query->InsertLink($currentUser, $linkUrl, $linkDescription, $linkTitle);


    $query->CloseConnection();

}

/**
 * Description: Selects all of the current users' post information
 * @param $currentUser
 * @return array
 */
function SelectAllCurrentUser($currentUser)
{
    $PostArray = array();

    $query = new DatabaseQuery(USER, PASS, CONNETIONSTRING);
    $selectAll = $query->SelectAllCurrentUser("backlinqs_post", $currentUser);
    $query->CloseConnection();

    foreach($selectAll as $item)
    {
        array_push($PostArray, $item);
    }

    return $PostArray;

}

/**
 * Description: Selects all the post titles
 * @return array of post titles
 */
function GetAllPostTitles()
{
    $PostTitlesArray = array();

    $query = new DatabaseQuery(USER, PASS, CONNETIONSTRING);
    $selectAll = $query->SelectAllPostTitles();
    //var_dump($selectAll);
    $query->CloseConnection();

    foreach($selectAll as $item)
    {
       // var_dump($item['Title']);
        array_push($PostTitlesArray, $item['Title']);
    }

    //var_dump($PostTitlesArray);
    return $PostTitlesArray;

}

/**
 * Description: Checks all the post titles for duplicates.
 * @param $title
 * @return bool
 */
function CheckPostTitles($title)
{
    $postTitles = GetAllPostTitles();

    $trueOrFalse = in_array($title, $postTitles);

    return $trueOrFalse;
}

function SelectAllCurrentUserLinks($currentUser)
{
    $PostTitleArray = array();

    $query = new DatabaseQuery(USER, PASS, CONNETIONSTRING);
    $selectAll = $query->SelectAllCurrentUser("backlinqs_links", $currentUser);
    $query->CloseConnection();

    foreach($selectAll as $item)
    {
        array_push($PostTitleArray, $item['Title']);
    }

    return $PostTitleArray;

}

function UpdatePost()
{

}

function GetAllUsers()
{
    $query = new DatabaseQuery(USER, PASS, CONNETIONSTRING);

    $allUsers = $query->SelectAllUsers();

    $query->CloseConnection();

    return $allUsers;
}

function CreateNewUser($firstName, $lastName, $email, $passHash)
{

        $query = new DatabaseQuery(USER, PASS, CONNETIONSTRING);

        $query->CreateUser($firstName, $lastName, $email, HashPass($passHash));

        $query->CloseConnection();


}

function UserLogin($email)
{
    $query = new DatabaseQuery(USER, PASS, CONNETIONSTRING);

    $query->Login($email);

    $query->CloseConnection();
}

function CheckForUniqueUserUponCreation($firstName, $lastName, $email, $passHash)
{
    $emailArray = array();
    $allUsers = GetAllUsers();

    foreach ($allUsers as $user)
    {
        array_push($emailArray, $user['Email']);
    }

    if(!in_array($email, $emailArray))
    {
        if($email != null || $email != '')
        {

            if($_SESSION['confirmPassword'] == $_SESSION['inputPassword'])
            {
                CreateNewUser($firstName, $lastName, $email, $passHash);
                echo 'User Created';
                session_destroy();
                return false;
            }
            else{
                echo 'Confirm password and password must match! Please try again.';
                session_destroy();
                return true;
            }


        }

    }
    else {
        echo 'User Already Exists';
        session_destroy();
        return true;
    }

}

function HashPass($userPass)
{
    return password_hash($userPass, PASSWORD_DEFAULT);
}

function VerifyHashPass($pass, $hash)
{
    return password_verify($pass, $hash);
}

function VerifyUser($email, $pass)
{

    $allUsers = GetAllUsers();

    foreach ($allUsers as $key=>$value)
    {

        if($value['Email'] == $email)
        {

            $verify = VerifyHashPass($pass, $value['PassHash']);


           if($verify == true)
           {

               UserLogin($email);
               unset($_SESSION['inputPassword']);
               return true;
           }
           else{
               //session_destroy();
               return false;
           }
        }
    }
}

function CheckUserStatusQuery($user)
{
    $query = new DatabaseQuery(USER, PASS, CONNETIONSTRING);

    $userStatus= $query->CheckLoginStatus($user);

    $query->CloseConnection();

    return $userStatus;
}

function GetCurrentUserIdQuery($user)
{
    $query = new DatabaseQuery(USER, PASS, CONNETIONSTRING);

    $userStatus= $query->GetCurrentUserId($user);

    foreach ($userStatus as $id)
    {

        return $id['ID'];
    }

    $query->CloseConnection();

    //return $userStatus;
}

function CheckUserStatus($user)
{
    $status = CheckUserStatusQuery($user);

    foreach($status as $item)
    {
        if( $item['Status'][0] == "0")
        {
            return false;
        }
        elseif ( $item['Status'][0] == "1")
        {
            return true;
        }
        else
        {
            return false;

        }
        break;
    }
}

function LogOutUserQuery($user)
{

    $query = new DatabaseQuery(USER, PASS, CONNETIONSTRING);

    $userStatus= $query->LogOut($user);

    $query->CloseConnection();



    return $userStatus;
}