<?php

include_once 'routing.php';

StartApp();

